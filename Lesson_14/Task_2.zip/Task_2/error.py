class GroupLimitError(Exception):
    pass